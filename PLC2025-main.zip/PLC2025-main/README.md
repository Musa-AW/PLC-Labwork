# Programming Language Concepts code for Aston University students
```diff
+ This repo is the PLC module starting in January 2025.
```

## Editing and running the code via a web browser

- Make an account on [gitpod.io](https://gitpod.io)
- Open an IDE using [this link](https://gitpod.io/#https://github.com/khanAston/PLC2025).
