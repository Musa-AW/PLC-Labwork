typedef struct B { int b;  } BB;
typedef struct A { struct A left; struct A right; } AA; 
