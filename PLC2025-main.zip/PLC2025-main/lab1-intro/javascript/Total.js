//Counter using While loop
//Source: Eloquent JavaScript (M. Haverbeke)
let total = 0, count = 1;
while (count <= 10) {
total += count;
count += 1;
}
console.log(total);