count = 1
total = 0
# use while loop to iterate to 10
while(count <= 10):
    total += count
    count += 1
print("The total is", total)