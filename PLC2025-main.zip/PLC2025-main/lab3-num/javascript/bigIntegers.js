const num1 = Number.MAX_SAFE_INTEGER+1; 
const num2 = Number.MAX_SAFE_INTEGER+2; 
console.log("max number:",Number.MAX_SAFE_INTEGER) 
console.log("after adding 1 and 2",num1, num2) 
console.log("Comparing both numbers:",num1===num2)